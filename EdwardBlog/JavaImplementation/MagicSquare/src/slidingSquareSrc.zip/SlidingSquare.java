import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class creates a ixj square puzzle problem, with random starting squares.
 * The starting squares are found using a Knuth-Fischer-Yates shuffle.  
 * Please view the following blog post (http://blog.codinghorror.com/the-danger-of-naivete/)
 * for information on potential mistakes in the Shuffle.
 * The generated square should have a 50% chance of being solvable.
 */
public class SlidingSquare
{
	//The valid directions the square can be moved.
	public static enum DIRECTION {UP, LEFT, DOWN, RIGHT};
	
	//This is where the data for the fifteen square is stored.
	private byte [][] squares;
	
	private byte height;
	private byte width;
	
	
	//This is the only position that can be moved.
	private Point emptyPosition;
	
	/**
	 * This has all the previously visited squares so that we can display
	 *  which choices were made to solve the magic square.
	 */
	private List<DIRECTION> previouslyVisited;
	
	/**
	 * Creates an ixj square with the elements in random spots.
	 */
	public SlidingSquare(byte height, byte width)
	{
		// Initial declarations.
		previouslyVisited=new ArrayList<DIRECTION>();
		this.height=height;
		this.width=width;
		squares=new byte[height][width];
		byte [] randomValues=new byte[height*width];
		//Create the elements.
		for(byte i=0; i<randomValues.length; i++)
		{
			randomValues[i]=i;
		}
		
		//Shuffle the elements.
		for(int i=randomValues.length-1; i>0; i--)
		{
			byte val=(byte)(Math.random()*(i+1));
			byte temp=randomValues[i];
			randomValues[i]=randomValues[val];
			randomValues[val]=temp;
		}
		
		//Place the shuffled elements in the correct location.
		for(int i=0, r=0; i<height; i++)
		{
			for(int j=0; j<width; j++, r++)
			{
				squares[i][j]=randomValues[r];
				if(squares[i][j]==0)
				{
					emptyPosition=new Point(i,j);
				}
			}
		}
	}
	
	/**
	 * Duplicate a Sliding square.
	 * @param ms
	 */
	private SlidingSquare(SlidingSquare ms)
	{
		previouslyVisited=new ArrayList<DIRECTION>(ms.previouslyVisited);
		squares=new byte[ms.height][ms.width];
		this.height=ms.height;
		this.width=ms.width;
		this.emptyPosition=ms.emptyPosition;
		for(int i=0; i<height; i++)
		{
			for(int j=0; j<width; j++)
			{
				squares[i][j]=ms.squares[i][j];
			}
		}
	}
	
	/**
	 * Check to see if the fifteen square is in the proper order.
	 * @return
	 */
	public boolean isSolved()
	{
		int r=0;
		for(byte [] row : squares)
			for(byte cell:row)
				if(r==cell)
					r++;
				else
					return false;
		return true;
	}
	
	/**
	 * Creates a new Square and moves it in direction d.
	 * The new square will have the current square in the previously visited list.
	 * This is done to prevent making a duplicate of the previous square twice.
	 * If the move cannot be made, returns null.
	 * @param d
	 * @return
	 */
	public SlidingSquare move(DIRECTION d)
	{
		if(canMove(d))
		{
			Point newPos=null;
			newPos=new Point(emptyPosition);
			newPos.move(d);
			SlidingSquare ms=new SlidingSquare(this);
			ms.previouslyVisited.add(d);
			ms.swap(emptyPosition, newPos);
			return ms;
		}
		else
			return null;
		
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb=new StringBuilder();
		for(byte [] row : squares)
		{
			for(byte cell:row)
			{
				sb.append(cell);
				sb.append('\t');
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	
	public List<DIRECTION> getPreviouslyVisited()
	{
		return previouslyVisited;
	}
	
	private boolean canMove(DIRECTION d)
	{
		switch(d)
		{
		case DOWN:
			if(emptyPosition.heightPos==height-1)
				return false;
			break;
		case LEFT:
			if(emptyPosition.widthPos==0)
				return false;
			break;
		case RIGHT:
			if(emptyPosition.widthPos==width-1)
				return false;
			break;
		case UP:
			if(emptyPosition.heightPos==0)
				return false;
			break;			
		}
		return true;
	}
	

	
	/**
	 * This function swaps two points in the magic square.  The only point that
	 * can be swapped is the "emptyPosition".
	 * @param one
	 * @param two
	 */
	private void swap(Point one, Point two)
	{
		
		byte temp=squares[one.heightPos][one.widthPos];
		//The square can't be swapped.
		if(temp!=0 && squares[two.heightPos][two.widthPos]!=0)
			return;
		squares[one.heightPos][one.widthPos]=squares[two.heightPos][two.widthPos];
		squares[two.heightPos][two.widthPos]=temp;
		if(temp==0)
		{
			emptyPosition=two;
		}
		else if(squares[one.heightPos][one.widthPos]==0)
		{
			emptyPosition=one;
		}
	}


	private class Point
	{
		public Point(Point p)
		{
			this(p.heightPos, p.widthPos);
		}
		public Point(int heightPos, int widthPos)
		{
			this.widthPos=widthPos;
			this.heightPos=heightPos;
		}
		public void move(DIRECTION d)
		{
			switch(d)
			{
			case DOWN:
				this.heightPos++;
				break;
			case LEFT:
				this.widthPos--;
				break;
			case RIGHT:
				this.widthPos++;
				break;
			case UP:
				this.heightPos--;
				break;			
			}
		}
		
		private int widthPos;
		private int heightPos;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(squares);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SlidingSquare other = (SlidingSquare) obj;
		if (!Arrays.deepEquals(squares, other.squares))
			return false;
		return true;
	}

}